'use strict';

const _i = ['高级设置', [0, 0, 5], 0, 0];

function reset() {
    SaveData('judge_width', 0.117775);
    SaveData('set-scale-ratio', "8e3");
    SaveData('canchange', "1");
    SaveData('use-random', false);
    SaveData('taprandom', 0);
    SaveData('holdrandom', 0);
    SaveData('flickrandom', 0)
    SaveData('dragrandom', 0);
    SaveData('sendError', "all");
    SaveData('sendError_debug', false);
    SaveData('speed-fix', true);
    alert('重置完成');
    location.reload(true);
}

const judge_width = document.getElementById('judge_width');
const selectscaleratio = document.getElementById('select-scale-ratio');
const canchange = document.getElementById('canchange');
const sendError = document.getElementById('sendError');
const sendError_debug = document.getElementById('sendError_debug');

judge_width.value = Number(ReadData('judge_width'));
selectscaleratio.value = Number(ReadData('set-scale-ratio'));
if (ReadData('canchange') == '1') canchange.checked = true;
if (ReadData('sendError') == 'all') sendError.checked = true;
if (ReadData('sendError_debug') == 'true') sendError_debug.checked = true;




judge_width.addEventListener('input', function() {
    SaveData('judge_width', judge_width.value);
});

selectscaleratio.addEventListener('input', function() {
    SaveData('set-scale-ratio', selectscaleratio.value);
});

canchange.addEventListener('input', function() {
    if (canchange.checked) SaveData('canchange', '1');
    else SaveData('canchange', '0');
});

sendError.addEventListener('input', function() {
    if (sendError.checked) SaveData('sendError', 'all');
    else SaveData('sendError', 'n');
});

sendError_debug.addEventListener('input', function() {
    SaveData('sendError_debug', sendError_debug.checked);
});