'use strict';

const _i = ['高级设置', [0, 0, 4], 0, 0];

function reset() {
    SaveData('judge_width', 1.777778);
    SaveData('set-scale-ratio', "8e3");
    SaveData('canchange', "1");
    SaveData('use-random', false);
    SaveData('taprandom', 0);
    SaveData('holdrandom', 0);
    SaveData('flickrandom', 0)
    SaveData('dragrandom', 0);
    SaveData('speed-fix', true);
    alert('重置完成');
    location.reload(true);
}

const judge_width = document.getElementById('judge_width');
const selectscaleratio = document.getElementById('select-scale-ratio');
const canchange = document.getElementById('canchange');


judge_width.value = Number(ReadData('judge_width'));
selectscaleratio.value = Number(ReadData('set-scale-ratio'));
if (ReadData('canchange') == '1') canchange.checked = true;


judge_width.addEventListener('input', function() {
    SaveData('judge_width', judge_width.value);
});

selectscaleratio.addEventListener('input', function() {
    SaveData('set-scale-ratio', selectscaleratio.value);
});

canchange.addEventListener('input', function() {
    if (canchange.checked) SaveData('canchange', '1');
    else SaveData('canchange', '0');
});

