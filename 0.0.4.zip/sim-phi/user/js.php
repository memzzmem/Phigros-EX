<?php
$url = "./users/". $_POST['uid']. "/login.txt";
echo $url;
if (file_exists($url)){
   file_put_contents($url, file_get_contents($url) + 1);
}
else file_put_contents($url, 1);

if (file_exists("./users/login.txt")){
   file_put_contents("./users/login.txt", file_get_contents("./users/login.txt") + 1);
}
else file_put_contents("./users/login.txt", 1);
?>