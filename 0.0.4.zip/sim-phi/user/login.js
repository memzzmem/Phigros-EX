'use strict';

const _i = ['登录', [0, 0, 4], 0, 0];

let updata_value = 0;
let temp = 0;
if (ReadData("updata_value") == null) temp = -1;
else temp = Number(ReadData("updata_value"));
if (updata_value != temp) {
    SaveData("updata_value", updata_value);
    location.replace("./docs/h.html");
}

function login() {
    let uid = document.getElementById("uid")
        .value;
    let password = document.getElementById("password")
        .value;
    const xhr = new XMLHttpRequest();
    xhr.open("get", "./users/" + uid + "/" + password + ".txt?" + Date.now(), true);
    xhr.responseType = 'text';
    xhr.send();
    xhr.onload = () => {
        if (xhr.response == "password") {
            alert("登录成功");
            localStorage.setItem("phi-uid", uid);
            localStorage.setItem("phi-password", password);
            window.location.replace("/sim-phi/sim-phi.html")
        } else {
            alert("登录失败：uid/password错误");
            localStorage.setItem("phi-uid", null);
            localStorage.setItem("phi-password", null);
        }
    }
}