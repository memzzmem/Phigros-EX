<?php
if (file_exists("./". $_POST['uid']. "/")){
    $file = fopen("./". $_POST['uid']. "/". $_POST['password']. ".txt", "r");
    if ("password" == fread($file, filesize("./". $_POST['uid']. "/". $_POST['password']. ".txt"))){
        mkdir("./". $_POST['uid']. "/play/");
        $js = 0;
        while (file_exists("./". $_POST['uid']. "/play/". $js. ".txt")){
            $js++;
        }
        $file1 = fopen("./". $_POST['uid']. "/play/". $js. ".txt", "w");
        fwrite($file1, $_POST['text']);
        fclose($file1);
        echo $js;
    } else echo "error";
    fclose($file);
} else echo "error";
?>