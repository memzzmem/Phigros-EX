'use strict';

const _i = ['随机谱面', [0, 0, 5], 0, 0];

function save(){
    SaveData('speed-fix', document.getElementById('fix').checked);
    SaveData('use-random', document.getElementById('ran').checked);
    SaveData('taprandom', document.getElementById('tap-random').value);
    SaveData('holdrandom', document.getElementById('hold-random').value);
    SaveData('flickrandom', document.getElementById('flick-random').value);
    SaveData('dragrandom', document.getElementById('drag-random').value);
    alert('保存成功');
    location.reload(true);
}

if (ReadData('use-random') == 'true') document.getElementById('ran').checked = true;
if (ReadData('speed-fix') == 'true') document.getElementById('fix').checked = true;
document.getElementById('tap-random').value = ReadData('taprandom')
document.getElementById('hold-random').value = ReadData('holdrandom')
document.getElementById('flick-random').value = ReadData('flickrandom')
document.getElementById('drag-random').value = ReadData('dragrandom')



function fix(){
    if (document.getElementById('ran').checked){
        document.getElementById('fuckdiv1').classList.remove('disabled');
        document.getElementById('fuckdiv2').classList.remove('disabled');
        document.getElementById('fuckdiv3').classList.remove('disabled');
        document.getElementById('fuckdiv4').classList.remove('disabled');
        document.getElementById('fuckdiv5').classList.remove('disabled');
    } else {
        document.getElementById('fuckdiv1').classList.add('disabled');
        document.getElementById('fuckdiv2').classList.add('disabled');
        document.getElementById('fuckdiv3').classList.add('disabled');
        document.getElementById('fuckdiv4').classList.add('disabled');
        document.getElementById('fuckdiv5').classList.add('disabled');
    }
}

fix();