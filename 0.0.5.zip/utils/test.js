'use strict';

function SaveData(cname, cvalue) {
    localStorage.setItem(cname, cvalue);
}

function ReadData(cname) {
    return localStorage.getItem(cname);
}

//初始化
if (!ReadData("judge_width")) SaveData("judge_width", "0.117775");
if (!ReadData("select-scale-ratio")) SaveData("select-scale-ratio", "8e3");
if (!ReadData("set-scale-ratio")) SaveData("set-scale-ratio", "8e3");
if (!ReadData("canchange")) SaveData("canchange", "1");
if (!ReadData("showPoint")) SaveData("showPoint", "false");
if (!ReadData("lineColor")) SaveData("lineColor", "true");
if (!ReadData("hitSong")) SaveData("hitSong", "true");
if (!ReadData("showCE2")) SaveData("showCE2", "false");
if (!ReadData("highLight")) SaveData("highLight", "true");
if (!ReadData("imageBlur")) SaveData("imageBlur", "true");
if (!ReadData("feedback")) SaveData("feedback", "false");
if (!ReadData("select-aspect-ratio")) SaveData("select-aspect-ratio", "1.777778");
if (!ReadData("select-global-alpha")) SaveData("select-global-alpha", "0.6");
if (!ReadData("use-random")) SaveData("use-random", "false");
if (!ReadData("taprandom")) SaveData("taprandom", "0");
if (!ReadData("holdrandom")) SaveData("holdrandom", "0");
if (!ReadData("flickrandom")) SaveData("flickrandom", "0");
if (!ReadData("dragrandom")) SaveData("dragrandom", "0");
if (!ReadData("speed-fix")) SaveData("speed-fix", "true");
if (!ReadData("sendError")) SaveData("sendError", "all");
if (!ReadData("sendError_debug")) SaveData("sendError_debug", "false");
