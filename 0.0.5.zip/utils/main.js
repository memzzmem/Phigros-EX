'use strict';
(function() {
	const jct = document.cookie.match(/jct=(.+?)(;|$)/);
	const d = 'lchz\x683\x3473';
	const memzzmem1 = 'mem\x7a\x7amem';
	const w = `作者：<a style="text-decoration:underline"target="_blank"href="//space.bilibili.com/274753872">${d}</a>`;
    const memzzmem2 = `修改：<a style="text-decoration:underline"target="_blank"href="//space.bilibili.com/305797550">${memzzmem1}</a>`;
	if (!location.search) setInterval(Function.constructor(atob('ZGVidWdnZXI=')));
	if (typeof _i == 'undefined' || _i.length != 4) return;
	//if (!(jct && jct[1] == 'ok' || document.referrer)) return location.href = '/401.html';
	document.cookie = `jct=ok;path=/;max-age=${2e6}`
	document.title = `${_i[0]} - ${d}制作;${memzzmem1}修改`;
	for (const i of document.querySelectorAll('.title')) i.innerHTML = `${_i[0]}&nbsp;v${_i[1].join('.')}`;
	for (const i of document.querySelectorAll('.info')) i.innerHTML = `${w}  ${memzzmem2}<br>(${cnymd(_i[2])}制作)<br>最后更新于${cnymd(_i[3])}`;
	for (const i of document.querySelectorAll('.main')) i.style.display = 'block';

	function cnymd(time) {
		const d = new Date(time * 1e3);
		return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`;
	}
})();